export * from "./fact.ts";
